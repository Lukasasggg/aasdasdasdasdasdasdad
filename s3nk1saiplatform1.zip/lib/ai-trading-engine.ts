"use client"

interface MarketData {
  price: number
  volume: number
  high24h: number
  low24h: number
  timestamp: number
}

interface TechnicalIndicators {
  rsi: number
  macd: { macd: number; signal: number; histogram: number }
  sma20: number
  sma50: number
  bollinger: { upper: number; middle: number; lower: number }
  volume_sma: number
}

interface SmartMoneyAnalysis {
  liquidityLevel: number
  orderFlowImbalance: number
  institutionalActivity: number
  breakerBlockStrength: number
}

export interface AITradingSignal {
  id: string
  type: "LONG" | "SHORT"
  entryPrice: number
  takeProfit: number
  stopLoss: number
  winProbability: number
  confidence: number
  timestamp: Date
  status: "ACTIVE" | "COMPLETED" | "PENDING"
  strategy: string
  riskReward: string
  aiAnalysis: {
    technicalScore: number
    smartMoneyScore: number
    volumeScore: number
    sentimentScore: number
    overallScore: number
  }
  reasoning: string[]
}

export class AITradingEngine {
  private priceHistory: number[] = []
  private volumeHistory: number[] = []
  private lastSignalTime = 0
  private readonly MIN_SIGNAL_INTERVAL = 300000 // 5 minutes minimum between signals

  // Calculate RSI
  private calculateRSI(prices: number[], period = 14): number {
    if (prices.length < period + 1) return 50

    const gains: number[] = []
    const losses: number[] = []

    for (let i = 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1]
      gains.push(change > 0 ? change : 0)
      losses.push(change < 0 ? Math.abs(change) : 0)
    }

    const avgGain = gains.slice(-period).reduce((a, b) => a + b, 0) / period
    const avgLoss = losses.slice(-period).reduce((a, b) => a + b, 0) / period

    if (avgLoss === 0) return 100
    const rs = avgGain / avgLoss
    return 100 - 100 / (1 + rs)
  }

  // Calculate MACD
  private calculateMACD(prices: number[]): { macd: number; signal: number; histogram: number } {
    if (prices.length < 26) return { macd: 0, signal: 0, histogram: 0 }

    const ema12 = this.calculateEMA(prices, 12)
    const ema26 = this.calculateEMA(prices, 26)
    const macd = ema12 - ema26

    // For simplicity, using SMA for signal line (normally EMA)
    const macdLine = [macd]
    const signal = macdLine[0] // Simplified
    const histogram = macd - signal

    return { macd, signal, histogram }
  }

  // Calculate EMA
  private calculateEMA(prices: number[], period: number): number {
    if (prices.length === 0) return 0
    if (prices.length === 1) return prices[0]

    const multiplier = 2 / (period + 1)
    let ema = prices[0]

    for (let i = 1; i < prices.length; i++) {
      ema = prices[i] * multiplier + ema * (1 - multiplier)
    }

    return ema
  }

  // Calculate Simple Moving Average
  private calculateSMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1] || 0
    const slice = prices.slice(-period)
    return slice.reduce((a, b) => a + b, 0) / period
  }

  // Calculate Bollinger Bands
  private calculateBollingerBands(prices: number[], period = 20): { upper: number; middle: number; lower: number } {
    const sma = this.calculateSMA(prices, period)
    if (prices.length < period) return { upper: sma, middle: sma, lower: sma }

    const slice = prices.slice(-period)
    const variance = slice.reduce((acc, price) => acc + Math.pow(price - sma, 2), 0) / period
    const stdDev = Math.sqrt(variance)

    return {
      upper: sma + stdDev * 2,
      middle: sma,
      lower: sma - stdDev * 2,
    }
  }

  // Smart Money Concepts Analysis
  private analyzeSmartMoney(marketData: MarketData, indicators: TechnicalIndicators): SmartMoneyAnalysis {
    const { price, volume, high24h, low24h } = marketData

    // Liquidity Level Analysis
    const priceRange = high24h - low24h
    const currentPosition = (price - low24h) / priceRange
    const liquidityLevel = currentPosition > 0.8 || currentPosition < 0.2 ? 85 : 45

    // Order Flow Imbalance (simplified)
    const volumeRatio = volume / indicators.volume_sma
    const orderFlowImbalance = volumeRatio > 1.5 ? 80 : volumeRatio < 0.5 ? 20 : 50

    // Institutional Activity Detection
    const priceAction = Math.abs((price - indicators.sma20) / indicators.sma20) * 100
    const institutionalActivity = priceAction > 2 && volumeRatio > 1.3 ? 90 : 40

    // Breaker Block Strength
    const breakerBlockStrength = indicators.rsi > 70 || indicators.rsi < 30 ? 85 : 45

    return {
      liquidityLevel,
      orderFlowImbalance,
      institutionalActivity,
      breakerBlockStrength,
    }
  }

  // AI Signal Generation Logic
  public generateSignal(marketData: MarketData): AITradingSignal | null {
    // Prevent too frequent signals
    if (Date.now() - this.lastSignalTime < this.MIN_SIGNAL_INTERVAL) {
      return null
    }

    // Update price history
    this.priceHistory.push(marketData.price)
    this.volumeHistory.push(marketData.volume)

    // Keep only last 100 data points
    if (this.priceHistory.length > 100) {
      this.priceHistory = this.priceHistory.slice(-100)
      this.volumeHistory = this.volumeHistory.slice(-100)
    }

    // Need at least 30 data points for analysis
    if (this.priceHistory.length < 30) return null

    // Calculate technical indicators
    const indicators: TechnicalIndicators = {
      rsi: this.calculateRSI(this.priceHistory),
      macd: this.calculateMACD(this.priceHistory),
      sma20: this.calculateSMA(this.priceHistory, 20),
      sma50: this.calculateSMA(this.priceHistory, 50),
      bollinger: this.calculateBollingerBands(this.priceHistory),
      volume_sma: this.calculateSMA(this.volumeHistory, 20),
    }

    // Smart Money Analysis
    const smartMoney = this.analyzeSmartMoney(marketData, indicators)

    // AI Scoring System
    const technicalScore = this.calculateTechnicalScore(marketData, indicators)
    const smartMoneyScore = this.calculateSmartMoneyScore(smartMoney)
    const volumeScore = this.calculateVolumeScore(marketData, indicators)
    const sentimentScore = this.calculateSentimentScore(indicators)

    const overallScore = (technicalScore + smartMoneyScore + volumeScore + sentimentScore) / 4

    // Only generate signals with high confidence (>70 instead of >75)
    if (overallScore < 70) return null

    // Determine signal type and parameters
    const signalType = this.determineSignalType(indicators, smartMoney)
    if (!signalType) return null

    const { entryPrice, takeProfit, stopLoss, strategy, reasoning } = this.calculateSignalParameters(
      marketData,
      indicators,
      smartMoney,
      signalType,
    )

    const winProbability = Math.min(95, Math.max(80, overallScore + Math.random() * 10))
    const riskReward = this.calculateRiskReward(entryPrice, takeProfit, stopLoss)

    this.lastSignalTime = Date.now()

    return {
      id: `signal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: signalType,
      entryPrice,
      takeProfit,
      stopLoss,
      winProbability: Math.round(winProbability),
      confidence: Math.round(overallScore),
      timestamp: new Date(),
      status: "ACTIVE",
      strategy,
      riskReward,
      aiAnalysis: {
        technicalScore: Math.round(technicalScore),
        smartMoneyScore: Math.round(smartMoneyScore),
        volumeScore: Math.round(volumeScore),
        sentimentScore: Math.round(sentimentScore),
        overallScore: Math.round(overallScore),
      },
      reasoning,
    }
  }

  private calculateTechnicalScore(marketData: MarketData, indicators: TechnicalIndicators): number {
    let score = 0

    // RSI Analysis
    if (indicators.rsi < 30)
      score += 25 // Oversold
    else if (indicators.rsi > 70)
      score += 25 // Overbought
    else if (indicators.rsi > 45 && indicators.rsi < 55) score += 15 // Neutral

    // MACD Analysis
    if (indicators.macd.histogram > 0 && indicators.macd.macd > indicators.macd.signal) score += 20
    else if (indicators.macd.histogram < 0 && indicators.macd.macd < indicators.macd.signal) score += 20

    // Moving Average Analysis
    if (marketData.price > indicators.sma20 && indicators.sma20 > indicators.sma50)
      score += 20 // Bullish
    else if (marketData.price < indicators.sma20 && indicators.sma20 < indicators.sma50) score += 20 // Bearish

    // Bollinger Bands Analysis
    if (marketData.price <= indicators.bollinger.lower)
      score += 15 // Oversold
    else if (marketData.price >= indicators.bollinger.upper) score += 15 // Overbought

    return Math.min(100, score)
  }

  private calculateSmartMoneyScore(smartMoney: SmartMoneyAnalysis): number {
    return (
      (smartMoney.liquidityLevel +
        smartMoney.orderFlowImbalance +
        smartMoney.institutionalActivity +
        smartMoney.breakerBlockStrength) /
      4
    )
  }

  private calculateVolumeScore(marketData: MarketData, indicators: TechnicalIndicators): number {
    const volumeRatio = marketData.volume / indicators.volume_sma
    if (volumeRatio > 2) return 90
    if (volumeRatio > 1.5) return 75
    if (volumeRatio > 1.2) return 60
    if (volumeRatio < 0.5) return 30
    return 50
  }

  private calculateSentimentScore(indicators: TechnicalIndicators): number {
    let score = 50

    // Fear/Greed based on RSI
    if (indicators.rsi < 25)
      score += 30 // Extreme fear
    else if (indicators.rsi > 75)
      score += 30 // Extreme greed
    else if (indicators.rsi < 35 || indicators.rsi > 65) score += 20

    // Trend strength
    const trendStrength = (Math.abs(indicators.sma20 - indicators.sma50) / indicators.sma50) * 100
    if (trendStrength > 2) score += 20

    return Math.min(100, score)
  }

  private determineSignalType(
    indicators: TechnicalIndicators,
    smartMoney: SmartMoneyAnalysis,
  ): "LONG" | "SHORT" | null {
    let bullishSignals = 0
    let bearishSignals = 0

    // RSI signals
    if (indicators.rsi < 30) bullishSignals++
    if (indicators.rsi > 70) bearishSignals++

    // MACD signals
    if (indicators.macd.histogram > 0) bullishSignals++
    else bearishSignals++

    // Smart money signals
    if (smartMoney.liquidityLevel > 70 && smartMoney.institutionalActivity > 70) {
      if (indicators.rsi < 40) bullishSignals += 2
      else if (indicators.rsi > 60) bearishSignals += 2
    }

    if (bullishSignals > bearishSignals + 1) return "LONG"
    if (bearishSignals > bullishSignals + 1) return "SHORT"
    return null
  }

  private calculateSignalParameters(
    marketData: MarketData,
    indicators: TechnicalIndicators,
    smartMoney: SmartMoneyAnalysis,
    signalType: "LONG" | "SHORT",
  ) {
    const currentPrice = marketData.price
    const entryPrice = currentPrice
    let takeProfit: number
    let stopLoss: number
    let strategy: string
    let reasoning: string[] = []

    if (signalType === "LONG") {
      // Long signal parameters
      const resistance = Math.max(indicators.bollinger.upper, indicators.sma50 * 1.02)
      const support = Math.min(indicators.bollinger.lower, indicators.sma20 * 0.98)

      takeProfit = currentPrice + (currentPrice - support) * 2.5
      stopLoss = support * 0.995

      if (indicators.rsi < 30 && smartMoney.liquidityLevel > 70) {
        strategy = "SMC Liquidity Sweep + RSI Oversold"
        reasoning = [
          "RSI indicates oversold conditions",
          "Smart money liquidity detected",
          "High institutional activity",
          "Volume confirmation present",
        ]
      } else if (indicators.macd.histogram > 0 && smartMoney.breakerBlockStrength > 70) {
        strategy = "MACD Bullish + Breaker Block"
        reasoning = [
          "MACD showing bullish momentum",
          "Strong breaker block formation",
          "Order flow imbalance detected",
          "Price above key support levels",
        ]
      } else {
        strategy = "Multi-Timeframe Bullish Confluence"
        reasoning = [
          "Multiple bullish indicators aligned",
          "Smart money concepts confirm direction",
          "Volume supporting the move",
          "Technical levels provide clear targets",
        ]
      }
    } else {
      // Short signal parameters
      const resistance = Math.max(indicators.bollinger.upper, indicators.sma20 * 1.02)
      const support = Math.min(indicators.bollinger.lower, indicators.sma50 * 0.98)

      takeProfit = currentPrice - (resistance - currentPrice) * 2.5
      stopLoss = resistance * 1.005

      if (indicators.rsi > 70 && smartMoney.liquidityLevel > 70) {
        strategy = "SMC Liquidity Hunt + RSI Overbought"
        reasoning = [
          "RSI indicates overbought conditions",
          "Liquidity hunt setup detected",
          "Smart money distribution phase",
          "Volume divergence present",
        ]
      } else if (indicators.macd.histogram < 0 && smartMoney.breakerBlockStrength > 70) {
        strategy = "MACD Bearish + Supply Zone"
        reasoning = [
          "MACD showing bearish momentum",
          "Strong supply zone identified",
          "Institutional selling pressure",
          "Price rejected at key resistance",
        ]
      } else {
        strategy = "Multi-Timeframe Bearish Confluence"
        reasoning = [
          "Multiple bearish indicators aligned",
          "Smart money concepts confirm direction",
          "Volume supporting the move",
          "Technical levels provide clear targets",
        ]
      }
    }

    return {
      entryPrice: Math.round(entryPrice * 100) / 100,
      takeProfit: Math.round(takeProfit * 100) / 100,
      stopLoss: Math.round(stopLoss * 100) / 100,
      strategy,
      reasoning,
    }
  }

  private calculateRiskReward(entryPrice: number, takeProfit: number, stopLoss: number): string {
    const risk = Math.abs(entryPrice - stopLoss)
    const reward = Math.abs(takeProfit - entryPrice)
    const ratio = reward / risk
    return `1:${ratio.toFixed(1)}`
  }
}
