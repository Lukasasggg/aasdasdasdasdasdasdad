"use client"

import { useEffect, useState, useRef } from "react"

interface WebSocketTicker {
  symbol: string
  lastPrice: string
  priceChangePercent: string
  volume24h: string
  timestamp: number
}

export function useBybitWebSocket() {
  const [ticker, setTicker] = useState<WebSocketTicker | null>(null)
  const [connected, setConnected] = useState(false)
  const wsRef = useRef<WebSocket | null>(null)
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  const connect = () => {
    try {
      const ws = new WebSocket("wss://stream.bybit.com/v5/public/spot")
      wsRef.current = ws

      ws.onopen = () => {
        console.log("Bybit WebSocket connected")
        setConnected(true)

        // Subscribe to BTC/USDT ticker
        ws.send(
          JSON.stringify({
            op: "subscribe",
            args: ["tickers.BTCUSDT"],
          }),
        )
      }

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)

          if (data.topic === "tickers.BTCUSDT" && data.data) {
            const tickerData = data.data
            setTicker({
              symbol: tickerData.symbol,
              lastPrice: tickerData.lastPrice,
              priceChangePercent: tickerData.price24hPcnt,
              volume24h: tickerData.volume24h,
              timestamp: Date.now(),
            })
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error)
        }
      }

      ws.onclose = () => {
        console.log("Bybit WebSocket disconnected")
        setConnected(false)

        // Attempt to reconnect after 5 seconds
        reconnectTimeoutRef.current = setTimeout(() => {
          connect()
        }, 5000)
      }

      ws.onerror = (error) => {
        console.error("Bybit WebSocket error:", error)
        setConnected(false)
      }
    } catch (error) {
      console.error("Failed to connect to Bybit WebSocket:", error)
    }
  }

  useEffect(() => {
    connect()

    return () => {
      if (wsRef.current) {
        wsRef.current.close()
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current)
      }
    }
  }, [])

  return { ticker, connected }
}
