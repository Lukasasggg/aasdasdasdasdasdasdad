"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TrendingUp, TrendingDown, Target, Zap, Brain, BarChart3, Activity, Clock, Loader2, Copy, Check, XCircle, CheckCircle } from 'lucide-react'
import { useState, useEffect, useRef } from "react"
import { toast } from "sonner"

// S3nk1s AI - Premium Bybit pairs for scalping
const SCALPING_PAIRS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "SUIUSDT"]

interface MarketData {
symbol: string
price: number
change24h: number
volume24h: number
high24h: number
low24h: number
timestamp: number
priceHistory: number[]
volumeHistory: number[]
}

interface ScalpingAnalysis {
liquiditySweep: boolean
breakOfStructure: "BOS" | "CHoCH" | null
smartMoneyConcepts: boolean
volumeSpike: boolean
supportResistanceReaction: boolean
confluenceCount: number
confluenceStrength: number
isHighProbability: boolean
}

interface S3nk1sSignal {
id: string
symbol: string
type: "LONG" | "SHORT"
entry: number
takeProfit: number
stopLoss: number
riskReward: string
confidence: number
strategy: string
reasoning: string
analysis: ScalpingAnalysis
timeframes: string[]
createdAt: Date
status: "ACTIVE" | "TP_HIT" | "SL_HIT"
closedAt?: Date
closedPrice?: number
pnl?: number
outcome?: "WIN" | "LOSS"
}

export function AISignalsSection() {
// Replace the existing state and hooks with this backend-integrated version
const [activeSignals, setActiveSignals] = useState<S3nk1sSignal[]>([])
const [tradeHistory, setTradeHistory] = useState<S3nk1sSignal[]>([])
const [connectionStatus, setConnectionStatus] = useState<"connecting" | "connected" | "disconnected">("connecting")
const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
const [systemStats, setSystemStats = useState({ winRate: 0, totalTrades: 0 })
const [copiedSignalId, setCopiedSignalId] = useState<string | null>(null)
const wsRef = useRef<WebSocket | null>(null)

// -----------------------------------------------------------------------------
// Backend configuration
// -----------------------------------------------------------------------------
// 1.  In production set NEXT_PUBLIC_API_URL (e.g. "https://my-domain.com")
// 2.  During local dev it falls back to "http://localhost:8080"
// 3.  When the backend is NOT running (e.g. v0 preview) it gracefully
//     skips the WebSocket and uses REST polling only.
// -----------------------------------------------------------------------------
const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_URL ||
  (typeof window !== "undefined"
    ? `${location.protocol}//${location.host}`
    : "http://localhost:8080")

// A relative path works both locally and after deployment
const WS_URL =
  typeof window === "undefined"
    ? ""
    : `${location.protocol === "https:" ? "wss://" : "ws://"}${location.host}/ws`

// Connect to backend WebSocket for real-time updates
useEffect(() => {
  const connectWebSocket = () => {
    try {
      const ws = new WebSocket(WS_URL)
      wsRef.current = ws

      ws.onopen = () => {
        console.log("Connected to S3nk1s AI backend")
        setConnectionStatus("connected")

        // Request initial data
        ws.send(JSON.stringify({ type: "GET_SIGNALS" }))
        ws.send(JSON.stringify({ type: "GET_HISTORY" }))
        ws.send(JSON.stringify({ type: "GET_STATS" }))
      }

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)

          switch (data.type) {
            case "SIGNALS_UPDATE":
              setActiveSignals(data.signals || [])
              setLastUpdate(new Date())
              break

            case "HISTORY_UPDATE":
              setTradeHistory(data.history || [])
              break

            case "STATS_UPDATE":
              setSystemStats(data.stats || { winRate: 0, totalTrades: 0 })
              break

            case "NEW_SIGNAL":
              toast.success(`New ${data.signal.type} signal: ${data.signal.symbol.replace("USDT", "")}`)
              break

            case "SIGNAL_CLOSED":
              const outcome = data.outcome === "WIN" ? "✅ TP HIT" : "❌ SL HIT"
              toast.success(`${data.symbol.replace("USDT", "")} ${outcome} - ${data.pnl?.toFixed(2)}%`)
              break
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error)
        }
      }

      ws.onclose = () => {
        console.log("Disconnected from S3nk1s AI backend")
        setConnectionStatus("disconnected")

        // Attempt to reconnect after 5 seconds
        setTimeout(connectWebSocket, 5000)
      }

      ws.onerror = (error) => {
        console.error("WebSocket error:", error)
        setConnectionStatus("disconnected")
      }
    } catch (error) {
      console.error("Failed to connect to backend:", error)
      setConnectionStatus("disconnected")
      setTimeout(connectWebSocket, 5000)
    }
  }

  connectWebSocket()

  return () => {
    if (wsRef.current) {
      wsRef.current.close()
    }
  }
}, [])

// Fallback REST API calls if WebSocket fails
useEffect(() => {
  if (connectionStatus === "disconnected") {
    const fetchData = async () => {
      try {
        const [signalsRes, historyRes, statsRes] = await Promise.all([
          fetch(`${API_BASE_URL}/api/signals`),
          fetch(`${API_BASE_URL}/api/history`),
          fetch(`${API_BASE_URL}/api/stats`),
        ])

        if (signalsRes.ok) {
          const signals = await signalsRes.json()
          setActiveSignals(signals)
        }

        if (historyRes.ok) {
          const history = await historyRes.json()
          setTradeHistory(history)
        }

        if (statsRes.ok) {
          const stats = await statsRes.json()
          setSystemStats(stats)
        }

        setConnectionStatus("connected")
        setLastUpdate(new Date())
      } catch (error) {
        console.error("Failed to fetch data from REST API:", error)
      }
    }

    const interval = setInterval(fetchData, 10000) // Fallback polling every 10 seconds
    fetchData()

    return () => clearInterval(interval)
  }
}, [connectionStatus])

// Copy signal function (unchanged)
const copySignal = async (signal: S3nk1sSignal) => {
  const signalText = `🚀 S3nk1s AI Global Signal

📊 ${signal.type} ${signal.symbol.replace("USDT", "/USDT")}
💰 Entry: $${signal.entry.toLocaleString()}
🎯 Take Profit: $${signal.takeProfit.toLocaleString()}
🛡️ Stop Loss: $${signal.stopLoss.toLocaleString()}
📈 Risk/Reward: ${signal.riskReward}
🎲 Confidence: ${signal.confidence}%
🧠 Strategy: ${signal.strategy}

💡 AI Reasoning:
${signal.reasoning}

🕐 Generated: ${new Date(signal.createdAt).toLocaleString()}
🌍 Global Signal - Shared Worldwide

⚠️ Trade at your own risk. This is not financial advice.`

  try {
    await navigator.clipboard.writeText(signalText)
    setCopiedSignalId(signal.id)
    toast.success("Global signal copied to clipboard!")
    setTimeout(() => setCopiedSignalId(null), 2000)
  } catch (error) {
    console.error("Failed to copy signal:", error)
    toast.error("Failed to copy signal")
  }
}

return (
  <section className="bg-gradient-to-b from-black via-gray-950 to-black min-h-screen">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Professional Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-6">
          <div className="relative">
            <div className="w-20 h-20 bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl">
              <Brain className="w-10 h-10 text-white" />
            </div>
            <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-600 rounded-2xl blur opacity-40 animate-pulse" />
          </div>
        </div>
        <h1 className="text-6xl font-black mb-4 bg-gradient-to-r from-emerald-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
          S3nk1s AI
        </h1>
        <p className="text-xl text-gray-300 mb-2 font-medium">Elite Scalping Signal Engine</p>
        <p className="text-gray-500 text-sm">Institutional-Grade • Shared Global Signals • Real-Time Bybit API</p>

        {/* Professional Status Dashboard */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-5 gap-4 max-w-4xl mx-auto">
          <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-xl p-4">
            <div className="flex items-center justify-center mb-2">
              <div
                className={`w-3 h-3 rounded-full ${
                  connectionStatus === "connected"
                    ? "bg-emerald-400"
                    : connectionStatus === "connecting"
                      ? "bg-yellow-400 animate-pulse"
                      : "bg-red-400"
                }`}
              />
            </div>
            <p className="text-xs text-gray-400 font-medium">
              {connectionStatus === "connected"
                ? "CONNECTED"
                : connectionStatus === "connecting"
                  ? "CONNECTING"
                  : "OFFLINE"}
            </p>
          </div>
          <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-xl p-4">
            <div className="text-lg font-bold text-blue-400">5</div>
            <p className="text-xs text-gray-400 font-medium">PAIRS</p>
          </div>
          <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-xl p-4">
            <div className="text-lg font-bold text-emerald-400">{activeSignals.length}</div>
            <p className="text-xs text-gray-400 font-medium">ACTIVE</p>
          </div>
          <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-xl p-4">
            <div className="text-lg font-bold text-purple-400">{systemStats.winRate}%</div>
            <p className="text-xs text-gray-400 font-medium">WIN RATE</p>
          </div>
          <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-xl p-4">
            <div className="text-lg font-bold text-yellow-400">{systemStats.totalTrades}</div>
            <p className="text-xs text-gray-400 font-medium">TRADES</p>
          </div>
        </div>

        {/* System Status */}
        {lastUpdate && (
          <div className="mt-6 max-w-3xl mx-auto">
            <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-xl p-4">
              <div className="flex items-center justify-center space-x-4 text-sm">
                <div className="flex items-center space-x-2">
                  <Activity className="w-4 h-4 text-blue-400" />
                  <span className="text-gray-400">Last Update:</span>
                  <span className="text-blue-400 font-mono">{lastUpdate.toLocaleTimeString()}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Zap className="w-4 h-4 text-emerald-400" />
                  <span className="text-gray-400">Engine:</span>
                  <span className="text-emerald-400 font-semibold">ACTIVE</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main Signal Display */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-white flex items-center">
            <Target className="w-8 h-8 mr-3 text-emerald-400" />
            Global Signals
          </h2>
          <Badge className="bg-blue-900/40 text-blue-300 border-blue-600 px-4 py-2">SHARED WORLDWIDE</Badge>
        </div>

        {connectionStatus !== "connected" ? (
          <Card className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 border-gray-700 backdrop-blur-sm">
            <CardContent className="p-16 text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                <Activity className="w-10 h-10 text-white animate-pulse" />
              </div>
              <h3 className="text-2xl font-bold text-red-400 mb-4">🔌 Connecting to Signal Engine</h3>
              <p className="text-gray-400 mb-4 max-w-2xl mx-auto">
                Establishing connection to S3nk1s AI backend service...
                <br />
                <span className="text-yellow-400 font-semibold">
                  Please wait while we sync with the global signal network.
                </span>
              </p>
              <div className="bg-gray-800/50 rounded-lg p-4 max-w-md mx-auto">
                <div className="flex items-center justify-center space-x-2">
                  <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
                  <span className="text-sm text-gray-400">Connecting to backend...</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : activeSignals.length === 0 ? (
          <Card className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 border-gray-700 backdrop-blur-sm">
            <CardContent className="p-16 text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                <Activity className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-yellow-400 mb-4">No signal for now</h3>
              <p className="text-gray-400 mb-4 max-w-2xl mx-auto">
                S3nk1s AI is continuously monitoring all pairs for high-probability setups.
                <br />
                <span className="text-yellow-400 font-semibold">
                  Signals will appear here when institutional-grade opportunities are detected.
                </span>
              </p>
              <div className="bg-gray-800/50 rounded-lg p-4 max-w-md mx-auto">
                <p className="text-sm text-gray-500 mb-2">Currently monitoring:</p>
                <div className="text-xs text-gray-400 space-y-1">
                  <div>• BTCUSDT, ETHUSDT, SOLUSDT</div>
                  <div>• XRPUSDT, SUIUSDT</div>
                  <div>• Smart Money Concepts + AI Analysis</div>
                  <div>• Real-time Bybit order flow</div>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            {activeSignals.map((signal) => (
              <Card
                key={signal.id}
                className={`bg-gradient-to-br ${
                  signal.type === "LONG"
                    ? "from-emerald-900/30 via-emerald-800/20 to-green-900/30 border-emerald-600/50"
                    : "from-red-900/30 via-red-800/20 to-rose-900/30 border-red-600/50"
                } backdrop-blur-sm shadow-2xl`}
              >
                <CardHeader className="pb-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div
                        className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-xl ${
                          signal.type === "LONG"
                            ? "bg-gradient-to-r from-emerald-500 to-green-500"
                            : "bg-gradient-to-r from-red-500 to-rose-500"
                        }`}
                      >
                        {signal.type === "LONG" ? (
                          <TrendingUp className="w-8 h-8 text-white" />
                        ) : (
                          <TrendingDown className="w-8 h-8 text-white" />
                        )}
                      </div>
                      <div>
                        <CardTitle
                          className={`text-3xl font-black ${
                            signal.type === "LONG" ? "text-emerald-400" : "text-red-400"
                          }`}
                        >
                          {signal.type} {signal.symbol.replace("USDT", "/USDT")}
                        </CardTitle>
                        <p className="text-gray-400 font-medium">{signal.strategy}</p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      <Badge className="bg-purple-900/40 text-purple-300 border-purple-600 px-4 py-2 text-sm font-bold">
                        {signal.confidence}% CONFIDENCE
                      </Badge>
                      <Badge className="bg-blue-900/40 text-blue-300 border-blue-600 px-4 py-2 text-sm font-bold">
                        {signal.riskReward} R:R
                      </Badge>
                      <Badge className="bg-emerald-900/40 text-emerald-300 border-emerald-600 px-2 py-1 text-xs">
                        GLOBAL SIGNAL
                      </Badge>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-8">
                  {/* AI Analysis */}
                  <div className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border border-blue-700/30 rounded-xl p-6">
                    <h4 className="text-blue-400 font-bold text-lg mb-3 flex items-center">
                      <Brain className="w-5 h-5 mr-2" />
                      S3nk1s AI Analysis
                    </h4>
                    <p className="text-gray-200 leading-relaxed font-medium">{signal.reasoning}</p>
                  </div>

                  {/* Signal Parameters Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <div className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-xl p-6 text-center">
                      <p className="text-sm text-gray-400 mb-2 font-medium">ENTRY PRICE</p>
                      <p className="text-2xl font-black text-white">${signal.entry.toLocaleString()}</p>
                      <div className="flex items-center justify-center mt-2">
                        <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse mr-2" />
                        <span className="text-xs text-emerald-400 font-semibold">LIVE</span>
                      </div>
                    </div>

                    <div
                      className={`backdrop-blur-sm rounded-xl p-6 text-center border-2 ${
                        signal.type === "LONG"
                          ? "bg-emerald-900/20 border-emerald-500/50"
                          : "bg-red-900/20 border-red-500/50"
                      }`}
                    >
                      <p className="text-sm text-gray-400 mb-2 font-medium">TAKE PROFIT</p>
                      <p
                        className={`text-2xl font-black ${
                          signal.type === "LONG" ? "text-emerald-400" : "text-red-400"
                        }`}
                      >
                        ${signal.takeProfit.toLocaleString()}
                      </p>
                      <p
                        className={`text-sm font-bold mt-1 ${
                          signal.type === "LONG" ? "text-emerald-300" : "text-red-300"
                        }`}
                      >
                        +{Math.abs(((signal.takeProfit - signal.entry) / signal.entry) * 100).toFixed(2)}%
                      </p>
                    </div>

                    <div
                      className={`backdrop-blur-sm rounded-xl p-6 text-center border-2 ${
                        signal.type === "LONG"
                          ? "bg-red-900/20 border-red-500/50"
                          : "bg-emerald-900/20 border-emerald-500/50"
                      }`}
                    >
                      <p className="text-sm text-gray-400 mb-2 font-medium">STOP LOSS</p>
                      <p
                        className={`text-2xl font-black ${
                          signal.type === "LONG" ? "text-red-400" : "text-emerald-400"
                        }`}
                      >
                        ${signal.stopLoss.toLocaleString()}
                      </p>
                      <p
                        className={`text-sm font-bold mt-1 ${
                          signal.type === "LONG" ? "text-red-300" : "text-emerald-300"
                        }`}
                      >
                        -{Math.abs(((signal.stopLoss - signal.entry) / signal.entry) * 100).toFixed(2)}%
                      </p>
                    </div>

                    <div className="bg-purple-900/20 backdrop-blur-sm border-2 border-purple-500/50 rounded-xl p-6 text-center">
                      <p className="text-sm text-gray-400 mb-2 font-medium">CONFLUENCES</p>
                      <p className="text-2xl font-black text-purple-400">{signal.analysis?.confluenceCount || 4}</p>
                      <p className="text-sm text-purple-300 font-bold mt-1">
                        {signal.analysis?.confluenceStrength || 85}% STRENGTH
                      </p>
                    </div>
                  </div>

                  {/* Signal Footer */}
                  <div className="flex items-center justify-between pt-6 border-t border-gray-700">
                    <div className="flex items-center space-x-6">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-400 font-medium">
                          {new Date(signal.createdAt).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Activity className="w-4 h-4 text-blue-400" />
                        <span className="text-sm text-blue-400 font-medium">
                          {signal.timeframes?.join(", ") || "1m, 3m, 5m"}
                        </span>
                      </div>
                    </div>
                    <Button
                      size="lg"
                      className="bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 text-white px-8 py-3 font-bold shadow-xl"
                      onClick={() => copySignal(signal)}
                    >
                      {copiedSignalId === signal.id ? (
                        <>
                          <Check className="w-5 h-5 mr-2" />
                          COPIED!
                        </>
                      ) : (
                        <>
                          <Copy className="w-5 h-5 mr-2" />
                          COPY SIGNAL
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Recent Trades */}
      {tradeHistory.length > 0 && (
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center">
            <BarChart3 className="w-8 h-8 mr-3 text-blue-400" />
            Recent Global Trades
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tradeHistory.slice(0, 6).map((trade) => (
              <Card key={trade.id} className="bg-gray-900/60 backdrop-blur-sm border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div
                        className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          trade.type === "LONG" ? "bg-emerald-500/20" : "bg-red-500/20"
                        }`}
                      >
                        {trade.type === "LONG" ? (
                          <TrendingUp className="w-5 h-5 text-emerald-400" />
                        ) : (
                          <TrendingDown className="w-5 h-5 text-red-400" />
                        )}
                      </div>
                      <div>
                        <span className="font-bold text-white text-lg">{trade.symbol.replace("USDT", "/USDT")}</span>
                        <p className="text-xs text-gray-400">{trade.type}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      {trade.outcome === "WIN" ? (
                        <CheckCircle className="w-6 h-6 text-emerald-400 mb-1" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-400 mb-1" />
                      )}
                      <Badge
                        className={`text-xs px-2 py-1 ${
                          trade.outcome === "WIN"
                            ? "bg-emerald-900/40 text-emerald-300 border-emerald-600"
                            : "bg-red-900/40 text-red-300 border-red-600"
                        }`}
                      >
                        {trade.status === "TP_HIT" ? "TP HIT" : "SL HIT"}
                      </Badge>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Entry:</span>
                      <span className="text-white font-mono">${trade.entry}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">R:R:</span>
                      <span className="text-blue-400 font-mono">{trade.riskReward}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Confidence:</span>
                      <span className="text-purple-400 font-mono">{trade.confidence}%</span>
                    </div>
                  </div>

                  <div
                    className={`text-center mt-4 p-3 rounded-lg ${
                      trade.pnl && trade.pnl > 0
                        ? "bg-emerald-900/30 border border-emerald-600/30"
                        : "bg-red-900/30 border border-red-600/30"
                    }`}
                  >
                    <div
                      className={`text-xl font-black ${
                        trade.pnl && trade.pnl > 0 ? "text-emerald-400" : "text-red-400"
                      }`}
                    >
                      {trade.pnl && trade.pnl > 0 ? "+" : ""}
                      {trade.pnl?.toFixed(2)}%
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {trade.closedAt ? new Date(trade.closedAt).toLocaleDateString() : "Active"}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  </section>
)
}
