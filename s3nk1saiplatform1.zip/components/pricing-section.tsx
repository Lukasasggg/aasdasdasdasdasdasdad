"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, Zap, Crown, Rocket } from "lucide-react"

export function PricingSection() {
  const plans = [
    {
      name: "Starter",
      price: "$49",
      period: "/month",
      description: "Perfect for beginners",
      icon: Zap,
      features: [
        "5 AI signals per day",
        "Basic market analysis",
        "Email notifications",
        "Community access",
        "Mobile app access",
      ],
      popular: false,
    },
    {
      name: "Professional",
      price: "$149",
      period: "/month",
      description: "Most popular choice",
      icon: Crown,
      features: [
        "Unlimited AI signals",
        "Advanced market analysis",
        "Real-time notifications",
        "Signal history & analytics",
        "Priority support",
        "Custom alerts",
        "Risk management tools",
      ],
      popular: true,
    },
    {
      name: "Elite",
      price: "$299",
      period: "/month",
      description: "For serious traders",
      icon: Rocket,
      features: [
        "Everything in Professional",
        "Private Discord channel",
        "1-on-1 strategy sessions",
        "Custom signal parameters",
        "API access",
        "White-label solutions",
        "Dedicated account manager",
      ],
      popular: false,
    },
  ]

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-black to-gray-900">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
            Choose Your Plan
          </h2>
          <p className="text-gray-400 text-lg">Start your journey to consistent profits with our AI-powered signals</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative bg-gray-900/50 border-gray-800 backdrop-blur-sm hover:border-gray-700 transition-all duration-300 ${
                plan.popular ? "ring-2 ring-blue-500/50 scale-105" : ""
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  Most Popular
                </Badge>
              )}

              <CardHeader className="text-center pb-6">
                <div className="flex justify-center mb-4">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      plan.popular ? "bg-gradient-to-r from-blue-600 to-purple-600" : "bg-gray-800"
                    }`}
                  >
                    <plan.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <CardTitle className="text-2xl text-white mb-2">{plan.name}</CardTitle>
                <p className="text-gray-400 text-sm mb-4">{plan.description}</p>
                <div className="flex items-baseline justify-center">
                  <span className="text-4xl font-bold text-white">{plan.price}</span>
                  <span className="text-gray-400 ml-1">{plan.period}</span>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm">
                      <Check className="w-4 h-4 text-green-400 mr-3 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  className={`w-full ${
                    plan.popular
                      ? "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      : "bg-gray-800 hover:bg-gray-700 text-white"
                  }`}
                  size="lg"
                >
                  Get Started
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Card className="bg-gradient-to-r from-gray-900 to-gray-800 border-gray-700 max-w-4xl mx-auto">
            <CardContent className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div>
                  <div className="text-3xl font-bold text-green-400 mb-2">7-Day</div>
                  <p className="text-gray-400">Free Trial</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-400 mb-2">24/7</div>
                  <p className="text-gray-400">Support</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-purple-400 mb-2">30-Day</div>
                  <p className="text-gray-400">Money Back Guarantee</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
