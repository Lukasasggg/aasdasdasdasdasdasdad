"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Activity, Volume2, ExternalLink } from "lucide-react"
import { useEffect, useState } from "react"

interface BybitTicker {
  symbol: string
  lastPrice: string
  priceChangePercent: string
  volume24h: string
  highPrice24h: string
  lowPrice24h: string
}

export function LiveMarketDashboard() {
  const [marketData, setMarketData] = useState<BybitTicker | null>(null)
  const [loading, setLoading] = useState(true)

  // Fetch live data from Bybit API
  useEffect(() => {
    const fetchMarketData = async () => {
      try {
        const response = await fetch("https://api.bybit.com/v5/market/tickers?category=spot&symbol=BTCUSDT")
        const data = await response.json()

        if (data.result && data.result.list && data.result.list.length > 0) {
          const ticker = data.result.list[0]
          setMarketData({
            symbol: ticker.symbol,
            lastPrice: ticker.lastPrice,
            priceChangePercent: ticker.price24hPcnt,
            volume24h: ticker.volume24h,
            highPrice24h: ticker.highPrice24h,
            lowPrice24h: ticker.lowPrice24h,
          })
        }
        setLoading(false)
      } catch (error) {
        console.error("Error fetching market data:", error)
        setLoading(false)
      }
    }

    fetchMarketData()
    const interval = setInterval(fetchMarketData, 5000) // Update every 5 seconds

    return () => clearInterval(interval)
  }, [])

  // TradingView Widget
  useEffect(() => {
    const script = document.createElement("script")
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js"
    script.type = "text/javascript"
    script.async = true
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: "BYBIT:BTCUSDT",
      interval: "15",
      timezone: "Etc/UTC",
      theme: "dark",
      style: "1",
      locale: "en",
      enable_publishing: false,
      backgroundColor: "rgba(19, 23, 34, 1)",
      gridColor: "rgba(42, 46, 57, 0.5)",
      hide_top_toolbar: false,
      hide_legend: false,
      save_image: false,
      container_id: "tradingview_chart",
      studies: ["RSI@tv-basicstudies", "MACD@tv-basicstudies", "Volume@tv-basicstudies"],
      overrides: {
        "paneProperties.background": "#131722",
        "paneProperties.vertGridProperties.color": "#2A2E39",
        "paneProperties.horzGridProperties.color": "#2A2E39",
        "symbolWatermarkProperties.transparency": 90,
        "scalesProperties.textColor": "#AAA",
        "mainSeriesProperties.candleStyle.upColor": "#26a69a",
        "mainSeriesProperties.candleStyle.downColor": "#ef5350",
        "mainSeriesProperties.candleStyle.drawWick": true,
        "mainSeriesProperties.candleStyle.drawBorder": true,
        "mainSeriesProperties.candleStyle.borderColor": "#378658",
        "mainSeriesProperties.candleStyle.borderUpColor": "#26a69a",
        "mainSeriesProperties.candleStyle.borderDownColor": "#ef5350",
        "mainSeriesProperties.candleStyle.wickUpColor": "#26a69a",
        "mainSeriesProperties.candleStyle.wickDownColor": "#ef5350",
      },
    })

    const chartContainer = document.getElementById("tradingview_chart")
    if (chartContainer) {
      chartContainer.appendChild(script)
    }

    return () => {
      if (chartContainer) {
        chartContainer.innerHTML = ""
      }
    }
  }, [])

  const formatPrice = (price: string) => {
    return Number.parseFloat(price).toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  }

  const formatVolume = (volume: string) => {
    const vol = Number.parseFloat(volume)
    if (vol >= 1000000) {
      return `${(vol / 1000000).toFixed(1)}M`
    } else if (vol >= 1000) {
      return `${(vol / 1000).toFixed(1)}K`
    }
    return vol.toFixed(2)
  }

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-black to-gray-900">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Live Market Analysis
          </h2>
          <p className="text-gray-400 text-lg">Real-time BTC/USDT market data powered by Bybit & TradingView</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          {/* Live Price Card */}
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-300 flex items-center justify-between">
                <div className="flex items-center">
                  <Activity className="w-5 h-5 mr-2 text-blue-400" />
                  BTC/USDT
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2"></div>
                  <span className="text-xs text-green-400">LIVE</span>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="animate-pulse">
                  <div className="h-8 bg-gray-700 rounded mb-2"></div>
                  <div className="h-4 bg-gray-700 rounded w-20"></div>
                </div>
              ) : marketData ? (
                <>
                  <div className="text-2xl font-bold text-white mb-2">${formatPrice(marketData.lastPrice)}</div>
                  <div className="flex items-center">
                    {Number.parseFloat(marketData.priceChangePercent) >= 0 ? (
                      <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400 mr-1" />
                    )}
                    <span
                      className={`text-sm font-medium ${
                        Number.parseFloat(marketData.priceChangePercent) >= 0 ? "text-green-400" : "text-red-400"
                      }`}
                    >
                      {Number.parseFloat(marketData.priceChangePercent) >= 0 ? "+" : ""}
                      {(Number.parseFloat(marketData.priceChangePercent) * 100).toFixed(2)}%
                    </span>
                  </div>
                </>
              ) : (
                <div className="text-red-400">Failed to load</div>
              )}
            </CardContent>
          </Card>

          {/* 24h High */}
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-300">24h High</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="animate-pulse">
                  <div className="h-8 bg-gray-700 rounded"></div>
                </div>
              ) : marketData ? (
                <div className="text-2xl font-bold text-green-400">${formatPrice(marketData.highPrice24h)}</div>
              ) : (
                <div className="text-red-400">--</div>
              )}
            </CardContent>
          </Card>

          {/* 24h Low */}
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-300">24h Low</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="animate-pulse">
                  <div className="h-8 bg-gray-700 rounded"></div>
                </div>
              ) : marketData ? (
                <div className="text-2xl font-bold text-red-400">${formatPrice(marketData.lowPrice24h)}</div>
              ) : (
                <div className="text-red-400">--</div>
              )}
            </CardContent>
          </Card>

          {/* Volume */}
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-300 flex items-center">
                <Volume2 className="w-5 h-5 mr-2 text-purple-400" />
                24h Volume
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="animate-pulse">
                  <div className="h-8 bg-gray-700 rounded mb-2"></div>
                  <div className="h-4 bg-gray-700 rounded w-16"></div>
                </div>
              ) : marketData ? (
                <>
                  <div className="text-2xl font-bold text-white mb-1">{formatVolume(marketData.volume24h)} BTC</div>
                  <Badge variant="secondary" className="bg-purple-900/30 text-purple-300">
                    High Activity
                  </Badge>
                </>
              ) : (
                <div className="text-red-400">--</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* TradingView Chart */}
        <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl text-white flex items-center">
                <Activity className="w-6 h-6 mr-2 text-blue-400" />
                Advanced Chart Analysis
              </CardTitle>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="border-green-600 text-green-400">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2"></div>
                  Live Data
                </Badge>
                <a
                  href="https://www.tradingview.com/chart/?symbol=BYBIT%3ABTCUSDT"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              Real-time BTC/USDT chart with RSI, MACD, and Volume indicators powered by TradingView
            </p>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[600px] w-full">
              <div
                id="tradingview_chart"
                className="h-full w-full rounded-b-lg overflow-hidden"
                style={{ height: "600px" }}
              />
            </div>
          </CardContent>
        </Card>

        {/* Market Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-300">Market Sentiment</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-400 mb-2">Bullish</div>
              <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                <div className="bg-gradient-to-r from-green-500 to-green-400 h-2 rounded-full w-3/4"></div>
              </div>
              <p className="text-sm text-gray-400">75% Bullish Sentiment</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-300">Fear & Greed Index</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-400 mb-2">68</div>
              <Badge variant="secondary" className="bg-yellow-900/30 text-yellow-300">
                Greed
              </Badge>
              <p className="text-sm text-gray-400 mt-2">Market showing greed signals</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-300">Data Source</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Price Data:</span>
                  <Badge variant="outline" className="border-blue-600 text-blue-400">
                    Bybit API
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Charts:</span>
                  <Badge variant="outline" className="border-purple-600 text-purple-400">
                    TradingView
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Update:</span>
                  <span className="text-sm text-green-400">5s intervals</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
