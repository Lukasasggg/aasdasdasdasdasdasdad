"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Target, DollarSign, Award } from "lucide-react"

export function PerformanceStats() {
  const stats = [
    {
      title: "Overall Win Rate",
      value: "87.3%",
      change: "+2.1%",
      icon: Target,
      color: "text-green-400",
    },
    {
      title: "Total Signals",
      value: "2,847",
      change: "+156 this month",
      icon: TrendingUp,
      color: "text-blue-400",
    },
    {
      title: "Average R:R",
      value: "1:2.8",
      change: "Consistent",
      icon: Award,
      color: "text-purple-400",
    },
    {
      title: "Monthly ROI",
      value: "23.4%",
      change: "+4.2%",
      icon: DollarSign,
      color: "text-yellow-400",
    },
  ]

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-gray-900 to-black">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
            Performance Analytics
          </h2>
          <p className="text-gray-400 text-lg">Track record of consistent profitability and precision</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="bg-gray-900/50 border-gray-800 backdrop-blur-sm hover:border-gray-700 transition-colors"
            >
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-gray-400 flex items-center">
                  <stat.icon className={`w-4 h-4 mr-2 ${stat.color}`} />
                  {stat.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-3xl font-bold mb-1 ${stat.color}`}>{stat.value}</div>
                <p className="text-sm text-gray-500">{stat.change}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-xl text-white">Monthly Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { month: "December 2024", winRate: "89%", roi: "+28.3%", signals: 234 },
                  { month: "November 2024", winRate: "86%", roi: "+21.7%", signals: 198 },
                  { month: "October 2024", winRate: "91%", roi: "+31.2%", signals: 267 },
                  { month: "September 2024", winRate: "84%", roi: "+19.8%", signals: 189 },
                ].map((month, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                    <div>
                      <p className="text-white font-medium">{month.month}</p>
                      <p className="text-sm text-gray-400">{month.signals} signals</p>
                    </div>
                    <div className="text-right">
                      <p className="text-green-400 font-semibold">{month.winRate}</p>
                      <p className="text-yellow-400 text-sm">{month.roi}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-xl text-white">Strategy Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { strategy: "Smart Money Concepts", winRate: "92%", usage: "35%" },
                  { strategy: "Liquidity Sweeps", winRate: "88%", usage: "28%" },
                  { strategy: "Breaker Blocks", winRate: "85%", usage: "22%" },
                  { strategy: "Volume Spread Analysis", winRate: "83%", usage: "15%" },
                ].map((strategy, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <p className="text-white font-medium">{strategy.strategy}</p>
                      <div className="flex items-center space-x-4">
                        <span className="text-green-400 text-sm">{strategy.winRate}</span>
                        <span className="text-gray-400 text-sm">{strategy.usage}</span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
                        style={{ width: strategy.usage }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
