"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useEffect, useState } from "react"

interface OrderBookEntry {
  price: string
  size: string
}

interface OrderBook {
  bids: OrderBookEntry[]
  asks: OrderBookEntry[]
  timestamp: number
}

interface LiveOrderbookProps {
  symbol?: string
}

export function LiveOrderbook({ symbol: initialSymbol = "BTCUSDT" }: LiveOrderbookProps) {
  const [orderbook, setOrderbook] = useState<OrderBook | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentSymbol, setCurrentSymbol] = useState(initialSymbol)

  // Listen for symbol changes from the dropdown
  useEffect(() => {
    const handleSymbolChange = (event: CustomEvent) => {
      setCurrentSymbol(event.detail.symbol)
      setLoading(true)
    }

    window.addEventListener("orderbook-symbol-change", handleSymbolChange as EventListener)

    return () => {
      window.removeEventListener("orderbook-symbol-change", handleSymbolChange as EventListener)
    }
  }, [])

  useEffect(() => {
    setCurrentSymbol(initialSymbol)
  }, [initialSymbol])

  useEffect(() => {
    const fetchOrderbook = async () => {
      try {
        const response = await fetch(
          `https://api.bybit.com/v5/market/orderbook?category=spot&symbol=${currentSymbol}&limit=10`,
        )
        const data = await response.json()

        if (data.result) {
          setOrderbook({
            bids: data.result.b || [],
            asks: data.result.a || [],
            timestamp: Date.now(),
          })
        }
        setLoading(false)
      } catch (error) {
        console.error("Error fetching orderbook:", error)
        setLoading(false)
      }
    }

    fetchOrderbook()
    const interval = setInterval(fetchOrderbook, 2000) // Update every 2 seconds

    return () => clearInterval(interval)
  }, [currentSymbol])

  const formatPrice = (price: string) => {
    return Number.parseFloat(price).toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  }

  const formatSize = (size: string) => {
    return Number.parseFloat(size).toFixed(4)
  }

  return (
    <Card className="bg-gray-900/50 border-gray-800 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl text-white">
            Live Order Book - {currentSymbol.replace("USDT", "/USDT")}
          </CardTitle>
          <Badge variant="outline" className="border-green-600 text-green-400">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2"></div>
            Live
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="animate-pulse flex justify-between">
                <div className="h-4 bg-gray-700 rounded w-20"></div>
                <div className="h-4 bg-gray-700 rounded w-16"></div>
              </div>
            ))}
          </div>
        ) : orderbook ? (
          <div className="space-y-4">
            {/* Asks (Sell Orders) */}
            <div>
              <h4 className="text-sm font-medium text-red-400 mb-2">Asks (Sell)</h4>
              <div className="space-y-1">
                {orderbook.asks
                  .slice(0, 5)
                  .reverse()
                  .map((ask, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span className="text-red-400">${formatPrice(ask[0])}</span>
                      <span className="text-gray-400">{formatSize(ask[1])}</span>
                    </div>
                  ))}
              </div>
            </div>

            {/* Spread */}
            <div className="border-t border-gray-700 pt-2">
              <div className="text-center text-xs text-gray-500">
                Spread: $
                {(
                  Number.parseFloat(orderbook.asks[0]?.[0] || "0") - Number.parseFloat(orderbook.bids[0]?.[0] || "0")
                ).toFixed(2)}
              </div>
            </div>

            {/* Bids (Buy Orders) */}
            <div>
              <h4 className="text-sm font-medium text-green-400 mb-2">Bids (Buy)</h4>
              <div className="space-y-1">
                {orderbook.bids.slice(0, 5).map((bid, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="text-green-400">${formatPrice(bid[0])}</span>
                    <span className="text-gray-400">{formatSize(bid[1])}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="text-red-400 text-center">Failed to load orderbook</div>
        )}
      </CardContent>
    </Card>
  )
}
