"use client"

import { useEffect, useState } from "react"
import { TrendingUp, TrendingDown } from "lucide-react"

interface TickerData {
  symbol: string
  price: string
  change: string
  changePercent: string
}

export function LivePriceTicker() {
  const [tickers, setTickers] = useState<TickerData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTickers = async () => {
      try {
        const symbols = ["BTCUSDT", "ETHUSDT", "BNBUSDT", "ADAUSDT", "SOLUSDT"]
        const promises = symbols.map(async (symbol) => {
          const response = await fetch(`https://api.bybit.com/v5/market/tickers?category=spot&symbol=${symbol}`)
          const data = await response.json()
          if (data.result && data.result.list && data.result.list.length > 0) {
            const ticker = data.result.list[0]
            return {
              symbol: ticker.symbol,
              price: ticker.lastPrice,
              change: ticker.price24hPcnt,
              changePercent: (Number.parseFloat(ticker.price24hPcnt) * 100).toFixed(2),
            }
          }
          return null
        })

        const results = await Promise.all(promises)
        setTickers(results.filter(Boolean) as TickerData[])
        setLoading(false)
      } catch (error) {
        console.error("Error fetching tickers:", error)
        setLoading(false)
      }
    }

    fetchTickers()
    const interval = setInterval(fetchTickers, 10000) // Update every 10 seconds

    return () => clearInterval(interval)
  }, [])

  if (loading) {
    return (
      <div className="bg-gray-900 border-b border-gray-800 py-2">
        <div className="animate-pulse flex space-x-8 px-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center space-x-2">
              <div className="h-4 bg-gray-700 rounded w-16"></div>
              <div className="h-4 bg-gray-700 rounded w-12"></div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="bg-gray-900 border-b border-gray-800 py-2 overflow-hidden">
      <div className="flex animate-scroll space-x-8 px-4">
        {tickers.map((ticker, index) => (
          <div key={index} className="flex items-center space-x-2 whitespace-nowrap">
            <span className="text-white font-medium">{ticker.symbol.replace("USDT", "/USDT")}</span>
            <span className="text-gray-300">${Number.parseFloat(ticker.price).toLocaleString()}</span>
            <div className="flex items-center">
              {Number.parseFloat(ticker.change) >= 0 ? (
                <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
              ) : (
                <TrendingDown className="w-3 h-3 text-red-400 mr-1" />
              )}
              <span className={`text-xs ${Number.parseFloat(ticker.change) >= 0 ? "text-green-400" : "text-red-400"}`}>
                {Number.parseFloat(ticker.change) >= 0 ? "+" : ""}
                {ticker.changePercent}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
