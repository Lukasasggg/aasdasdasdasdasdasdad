import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "S3nk1s AI - Where AI meets Alpha | Premium Crypto Trading Signals",
  description:
    "Advanced AI-powered BTC/USDT trading signals with 87% win rate. Smart Money Concepts, liquidity analysis, and institutional-grade market intelligence.",
  keywords: "crypto trading signals, BTC USDT, AI trading, smart money concepts, trading bot, cryptocurrency analysis",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
