"use client"

import { LivePriceTicker } from "@/components/live-price-ticker"
import { HeroSection } from "@/components/hero-section"
import { LiveMarketDashboard } from "@/components/live-market-dashboard"
import { AISignalsSection } from "@/components/ai-signals-section" // ✅ correct path + named export
import { PerformanceStats } from "@/components/performance-stats"
import { PricingSection } from "@/components/pricing-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <LivePriceTicker />
      <HeroSection />
      <LiveMarketDashboard />
      <AISignalsSection />
      <PerformanceStats />
      <PricingSection />
      <Footer />
    </div>
  )
}
