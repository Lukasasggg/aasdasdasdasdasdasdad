import { type NextRequest, NextResponse } from "next/server"

const mockHistory = [
  {
    id: "trade_1",
    symbol: "BTCUSDT",
    type: "LONG",
    entry: 65800.0,
    takeProfit: 67500.0,
    stopLoss: 64900.0,
    confidence: 89,
    strategy: "Smart Money Reversal + Breaker Block",
    riskReward: "1:3.2",
    status: "TP_HIT",
    outcome: "WIN",
    pnl: 2.58,
    createdAt: new Date(Date.now() - 1800000), // 30 minutes ago
    closedAt: new Date(Date.now() - 600000), // 10 minutes ago
  },
]

export async function GET(request: NextRequest) {
  try {
    return NextResponse.json(mockHistory)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch history" }, { status: 500 })
  }
}
