import { type NextRequest, NextResponse } from "next/server"

// Mock signals for now - replace with real AI engine later
const mockSignals = [
  {
    id: "signal_1",
    symbol: "BTCUSDT",
    type: "LONG",
    entry: 67234.56,
    takeProfit: 68900.0,
    stopLoss: 66100.0,
    confidence: 87,
    strategy: "SMC Liquidity Sweep + RSI Oversold",
    riskReward: "1:2.8",
    reasoning: "RSI indicates oversold conditions with smart money liquidity detected at key support levels.",
    createdAt: new Date(),
    status: "ACTIVE",
  },
]

export async function GET(request: NextRequest) {
  try {
    return NextResponse.json(mockSignals)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch signals" }, { status: 500 })
  }
}
