import { type NextRequest, NextResponse } from "next/server"

const mockStats = {
  winRate: 87,
  totalTrades: 234,
  monthlyROI: 23.4,
  activeSignals: 2,
}

export async function GET(request: NextRequest) {
  try {
    return NextResponse.json(mockStats)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 })
  }
}
